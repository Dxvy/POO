#ifndef TP4_MAIN_H
#define TP4_MAIN_H

#ifdef _WIN32
#include <windows.h>
#endif

#include <iostream>
#include "TPCpp/menu.h"


/**
 * @brief Lance le TP4.
 */
int main();

#endif //TP4_MAIN_H
