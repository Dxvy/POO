//
// Created by davym on 28/04/2022.
//

#ifndef TP4_UTIL_H
#define TP4_UTIL_H

#include <iostream>
void selection();
int askIntInput(const std::string prompt);
#endif //TP4_UTIL_H
