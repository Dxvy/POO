#include "..\include\utils.h"


int main() {
    menu();
    return 0;
}
