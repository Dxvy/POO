//
// Created by kheir on 31/03/2022.
//
#pragma once
#include <iostream>
#include "exo1.h"
#include "exo2.h"
#include "exo3.h"
#include "exo4.h"
#include "exo5.h"

int askIntInput(const std::string prompt);
int askCharInput(const std::string prompt);
void menu();