//
// Created by kheir on 31/03/2022.
//
#pragma once
#include <iostream>
#include "utils.h"


void exo1();
void printPairs(int n);
void PrintNumberofPairs(int n);