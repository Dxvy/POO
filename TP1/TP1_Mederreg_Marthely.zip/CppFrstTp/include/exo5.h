//
// Created by kheir on 02/04/2022.
//

#pragma once
#include <iostream>
#include "utils.h"

void exo5();
