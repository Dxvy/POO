#pragma once

#ifdef _WIN32
#include <windows.h>
#endif

#include <iostream>
#include "menu.hpp"


/**
 * @brief Lance le TP3.
 */
int main();
